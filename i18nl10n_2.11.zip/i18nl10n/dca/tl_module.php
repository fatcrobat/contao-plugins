<?php if (!defined('TL_ROOT')) die('You can not access this file directly!');

// Palettes
$GLOBALS['TL_DCA']['tl_module']['palettes']['i18nl10nnav'] = '{title_legend},name,headline,type;'
.'{template_legend:hide},navigationTpl;{protected_legend:hide},protected;'
.'{expert_legend:hide},guests,cssID,space';
$GLOBALS['TL_DCA']['tl_module']['fields']['navigationTpl']['default']['nav_18nl10n_language_menu']
?>
